#ifndef LINKEDLIST_H_INCLUDED
#define LINKEDLIST_H_INCLUDED

typedef struct info{
    int value;
}Information;

typedef struct node{
    Information info;
    struct node *nextNode;
}Node;

Node* createLinkedList();

Node* insertElement(Node* list, Information info);

void printLinkedList(Node* list);

Node* retrieveElement(Node* list, int value);

Node* updateElement(Node* list, int value, int newValue);

Node* removeElement(Node* list, int value);



#endif // LINKEDLIST_H_INCLUDED
