#include "linkedlist.h"
#include <stdlib.h>

Node* createLinkedList(){
    return NULL;
}

Node* insertElement(Node* list, Information info){

printf("---> %d <---\n", info.value);

Node* newNode = (Node*) malloc(sizeof(Node));
newNode->info = info;
newNode->nextNode = list;

return newNode;

}

void printLinkedList(Node* list){
    Node* p = list;
    while(p!=NULL){
        printf("%d ->", p->info.value);
        p = p->nextNode;
    }
    printf(" NULL\n");
}

Node* retrieveElement(Node* list, int value){

    Node* p = list;
    while(p!=NULL){

        if(p->info.value == value){
             printf("Valor %d encontrado na lista. \n", value);
            return p;
        }
        p = p->nextNode;
    }

    printf("Valor %d nao encontrado na lista.\n", value);
    return NULL;
}

Node* updateElement(Node* list, int value, int newValue){

    Node* p = list;
    while(p!=NULL){

        if(p->info.value == value){
             printf("Valor %d encontrado na lista. \n", value);
             p->info.value=newValue;
             printf("Valor alterado de %d para %d na lista. \n", value, newValue);

            return p;
        }
        p = p->nextNode;
    }

    printf("Erro ao atualizar. %d nao encontrado.\n", value);
    return NULL;
}


Node* removeElement(Node* list, int value){

Node* ant = NULL;
Node* p = list;
while(p != NULL && p->info.value != value){
    ant = p;
    p=p->nextNode;
}

if(p== NULL){
    printf("Erro ao deletar. Valor %d nao encontrado na lista.\n", value);
    return NULL;
}

if(ant == NULL){
     Node* next = p->nextNode;
     free(p);
    printf("Valor %d deletado com sucesso no inicio da lista.\n", value);
    return next;
}else{
    ant->nextNode = p->nextNode;
    free(p);
    printf("Valor %d deletado com sucesso no meio da lista.\n", value);
    return list;
}



}

