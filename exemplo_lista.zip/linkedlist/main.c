#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

int main()
{
    int op = -1;
    Node* lista = createLinkedList();
    char letra;
    int num, num2;
    while(op!=6){
        system("cls");
        printf("O que deseja fazer?\n1-Adicionar\n2-Listar\n3-Buscar\n4-Atualizar\n5-Remover\n6-Sair\n");
        fflush(stdin);
        scanf("%d", &op);
        switch(op){
            case 1:
                printf("Digite o numero que deseja adicionar:\n");
                fflush(stdin);
                scanf("%d", &num);
                Information info;
                info.value = num;
                lista = insertElement(lista, info);
                printf("Elemento %d inserido com sucesso.\n", num);
                break;
            case 2:
                printLinkedList(lista);
                break;
            case 3:
                printf("Qual valor voce deseja buscar?\n");
                fflush(stdin);
                scanf("%d", &num);
                Node* result= retrieveElement(lista, num);
                break;
            case 4:
                printf("Qual valor voce deseja atualizar?\n");
                fflush(stdin);
                scanf("%d", &num);
                printf("Qual o novo valor desejado?\n");
                fflush(stdin);
                scanf("%d", &num2);
                updateElement(lista, num, num2);
                break;
            case 5:
                printf("Qual valor voce deseja remover?\n");
                fflush(stdin);
                scanf("%d", &num);
                lista = removeElement(lista, num);
                break;
            case 6:
                printf("Tem certeza que deseja sair?\n");
                fflush(stdin);
                scanf("%c", &letra);
                if(letra == 'n' || letra =='N'){
                    op = -1;
                }else{
                    return 0;
                }
                break;



        }

        system("pause");

    }



    return 0;
}
